package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val RaacPrimaryLight = Color(0xFF006C50)
val RaacOnPrimaryLight = Color(0xFFFFFFFF)
val RaacPrimaryContainerLight = Color(0xFF8CF5CF)
val RaacOnPrimaryContainerLight = Color(0xFF002116)

val RaacSecondaryLight = Color(0xFF4C6358)
val RaacOnSecondaryLight = Color(0xFFFFFFFF)
val RaacSecondaryContainerLight = Color(0xFFCEE9DB)
val RaacOnSecondaryContainerLight = Color(0xFF092017)

val RaacTertiaryLight = Color(0xFF3D6473)
val RaacOnTertiaryLight = Color(0xFFFFFFFF)
val RaacTertiaryContainerLight = Color(0xFFC0E8FB)
val RaacOnTertiaryContainerLight = Color(0xFF001F29)

val RaacBackgroundLight = Color(0xFFF6FBF6)
val RaacOnBackgroundLight = Color(0xFF181D1A)
val RaacSurfaceLight = Color(0xFFF6FBF6)
val RaacOnSurfaceLight = Color(0xFF181D1A)
val RaacSurfaceVariantLight = Color(0xFFDBE5DE)
val RaacOnSurfaceVariantLight = Color(0xFF404944)
val RaacOutlineLight = Color(0xFF707974)

// Dark Theme Colors
val RaacPrimaryDark = Color(0xFF6FD8B4)
val RaacOnPrimaryDark = Color(0xFF003828)
val RaacPrimaryContainerDark = Color(0xFF00513B)
val RaacOnPrimaryContainerDark = Color(0xFF8CF5CF)

val RaacSecondaryDark = Color(0xFFB2CCBF)
val RaacOnSecondaryDark = Color(0xFF1E352B)
val RaacSecondaryContainerDark = Color(0xFF354B41)
val RaacOnSecondaryContainerDark = Color(0xFFCEE9DB)

val RaacTertiaryDark = Color(0xFFA5CCDE)
val RaacOnTertiaryDark = Color(0xFF063544)
val RaacTertiaryContainerDark = Color(0xFF244C5B)
val RaacOnTertiaryContainerDark = Color(0xFFC0E8FB)

val RaacBackgroundDark = Color(0xFF101412)
val RaacOnBackgroundDark = Color(0xFFE0E3DF)
val RaacSurfaceDark = Color(0xFF101412)
val RaacOnSurfaceDark = Color(0xFFE0E3DF)
val RaacSurfaceVariantDark = Color(0xFF404944)
val RaacOnSurfaceVariantDark = Color(0xFFBFC9C3)
val RaacOutlineDark = Color(0xFF8A938D)

// Accents & Status
val StatusWarningAmber = Color(0xFFD97706)
val StatusWarningBg = Color(0xFFFEF3C7)
val StatusSuccessGreen = Color(0xFF15803D)
val StatusSuccessBg = Color(0xFFDCFCE7)
val StatusInfoBlue = Color(0xFF0284C7)
val StatusInfoBg = Color(0xFFE0F2FE)
