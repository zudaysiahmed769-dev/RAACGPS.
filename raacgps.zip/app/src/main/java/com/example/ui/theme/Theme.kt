package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = RaacPrimaryDark,
    onPrimary = RaacOnPrimaryDark,
    primaryContainer = RaacPrimaryContainerDark,
    onPrimaryContainer = RaacOnPrimaryContainerDark,
    secondary = RaacSecondaryDark,
    onSecondary = RaacOnSecondaryDark,
    secondaryContainer = RaacSecondaryContainerDark,
    onSecondaryContainer = RaacOnSecondaryContainerDark,
    tertiary = RaacTertiaryDark,
    onTertiary = RaacOnTertiaryDark,
    tertiaryContainer = RaacTertiaryContainerDark,
    onTertiaryContainer = RaacOnTertiaryContainerDark,
    background = RaacBackgroundDark,
    onBackground = RaacOnBackgroundDark,
    surface = RaacSurfaceDark,
    onSurface = RaacOnSurfaceDark,
    surfaceVariant = RaacSurfaceVariantDark,
    onSurfaceVariant = RaacOnSurfaceVariantDark,
    outline = RaacOutlineDark
  )

private val LightColorScheme =
  lightColorScheme(
    primary = RaacPrimaryLight,
    onPrimary = RaacOnPrimaryLight,
    primaryContainer = RaacPrimaryContainerLight,
    onPrimaryContainer = RaacOnPrimaryContainerLight,
    secondary = RaacSecondaryLight,
    onSecondary = RaacOnSecondaryLight,
    secondaryContainer = RaacSecondaryContainerLight,
    onSecondaryContainer = RaacOnSecondaryContainerLight,
    tertiary = RaacTertiaryLight,
    onTertiary = RaacOnTertiaryLight,
    tertiaryContainer = RaacTertiaryContainerLight,
    onTertiaryContainer = RaacOnTertiaryContainerLight,
    background = RaacBackgroundLight,
    onBackground = RaacOnBackgroundLight,
    surface = RaacSurfaceLight,
    onSurface = RaacOnSurfaceLight,
    surfaceVariant = RaacSurfaceVariantLight,
    onSurfaceVariant = RaacOnSurfaceVariantLight,
    outline = RaacOutlineLight
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use our curated palette for RaacGPS brand consistency
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
