package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.NavigationTab
import com.example.ui.components.FeatureNoticeDialog
import com.example.ui.components.PermissionExplanationDialog
import com.example.ui.screens.FamilySharingScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.RaacGpsViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: RaacGpsViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        RaacGpsApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun RaacGpsApp(viewModel: RaacGpsViewModel) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  // Verify permission status on launch without prompting
  LaunchedEffect(Unit) {
    val fineGranted = ContextCompat.checkSelfPermission(
      context,
      Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
    val coarseGranted = ContextCompat.checkSelfPermission(
      context,
      Manifest.permission.ACCESS_COARSE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    if (fineGranted || coarseGranted) {
      viewModel.onPermissionResult(true)
    }
  }

  // Location permission request launcher
  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions ->
    val isGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
      permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    viewModel.onPermissionResult(isGranted)
  }

  // Handle back button: return to Guriga (Home) if on another tab
  if (uiState.currentTab != NavigationTab.GURIGA) {
    BackHandler {
      viewModel.selectTab(NavigationTab.GURIGA)
    }
  }

  // Permission explanation dialog shown ONLY after tapping "Goobtayda"
  if (uiState.showPermissionExplanationDialog) {
    PermissionExplanationDialog(
      onConfirm = {
        viewModel.dismissPermissionExplanationDialog()
        permissionLauncher.launch(
          arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
          )
        )
      },
      onDismiss = {
        viewModel.dismissPermissionExplanationDialog()
      }
    )
  }

  // Informational notice dialog
  if (uiState.showFeatureNoticeDialog) {
    FeatureNoticeDialog(
      title = uiState.featureNoticeTitle,
      message = uiState.featureNoticeMessage,
      onDismiss = { viewModel.dismissFeatureNotice() }
    )
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    bottomBar = {
      NavigationBar(
        modifier = Modifier.testTag("bottom_navigation_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
      ) {
        NavigationTab.values().forEach { tab ->
          val isSelected = uiState.currentTab == tab
          NavigationBarItem(
            modifier = Modifier.testTag(tab.testTag),
            selected = isSelected,
            onClick = { viewModel.selectTab(tab) },
            icon = {
              Icon(
                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                contentDescription = tab.title
              )
            },
            label = {
              Text(
                text = tab.title,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
              selectedTextColor = MaterialTheme.colorScheme.primary,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer,
              unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
              unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
          )
        }
      }
    }
  ) { innerPadding ->
    when (uiState.currentTab) {
      NavigationTab.GURIGA -> {
        HomeScreen(
          uiState = uiState,
          onNavigateTab = { viewModel.selectTab(it) },
          onMyLocationClick = { viewModel.onMyLocationClick() },
          onStartSharing = { viewModel.startLocationSharing() },
          onStopSharing = { viewModel.stopLocationSharing() },
          onZoomIn = { viewModel.zoomInMap() },
          onZoomOut = { viewModel.zoomOutMap() },
          modifier = Modifier.padding(innerPadding)
        )
      }

      NavigationTab.KHARIIDADDA -> {
        MapScreen(
          uiState = uiState,
          onMyLocationClick = { viewModel.onMyLocationClick() },
          onZoomIn = { viewModel.zoomInMap() },
          onZoomOut = { viewModel.zoomOutMap() },
          onSelectLayer = { viewModel.setMapLayer(it) },
          modifier = Modifier.padding(innerPadding)
        )
      }

      NavigationTab.QOYSKA -> {
        FamilySharingScreen(
          uiState = uiState,
          onStartSharing = { viewModel.startLocationSharing() },
          onStopSharing = { viewModel.stopLocationSharing() },
          onAddMemberClick = {
            viewModel.showFeatureNotice(
              title = "Ku Darista Xubinta Qoyska",
              message = "Wajiga 2aad marka Firebase Auth iyo database la hirgeliyo, waxaad abuuri kartaa kood gaar ah oo xubnaha qoyskaagu kaga soo biiraan kooxdaada."
            )
          },
          modifier = Modifier.padding(innerPadding)
        )
      }

      NavigationTab.DEJINTA -> {
        SettingsScreen(
          uiState = uiState,
          onMyLocationClick = { viewModel.onMyLocationClick() },
          onShowNotice = { title, msg -> viewModel.showFeatureNotice(title, msg) },
          modifier = Modifier.padding(innerPadding)
        )
      }
    }
  }
}
