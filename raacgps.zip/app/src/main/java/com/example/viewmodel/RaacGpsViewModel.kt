package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.model.NavigationTab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class RaacGpsUiState(
    val currentTab: NavigationTab = NavigationTab.GURIGA,
    val isSharingActive: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val isPermissionDenied: Boolean = false,
    val showPermissionExplanationDialog: Boolean = false,
    val showFeatureNoticeDialog: Boolean = false,
    val featureNoticeTitle: String = "",
    val featureNoticeMessage: String = "",
    val mapZoomLevel: Float = 1.0f,
    val selectedMapLayer: String = "Caadi"
)

class RaacGpsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(RaacGpsUiState())
    val uiState: StateFlow<RaacGpsUiState> = _uiState.asStateFlow()

    fun selectTab(tab: NavigationTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun onMyLocationClicked() {
        if (!_uiState.value.isPermissionGranted) {
            // Requirement: Add a location permission explanation and request permission only after user taps "Goobtayda"
            _uiState.update { it.copy(showPermissionExplanationDialog = true) }
        } else {
            // Already granted: Provide clear non-misleading feedback
            showFeatureNotice(
                title = "Goobtayda (GPS)",
                message = "Fasaxa goobta waa la oggolaaday. Xusuusnow: Wajigan (UI Only) ma jiro xog goobeed la ururinayo ama la daabacayo."
            )
        }
    }

    fun dismissPermissionExplanationDialog() {
        _uiState.update { it.copy(showPermissionExplanationDialog = false) }
    }

    fun onPermissionResult(isGranted: Boolean) {
        _uiState.update {
            it.copy(
                isPermissionGranted = isGranted,
                isPermissionDenied = !isGranted,
                showPermissionExplanationDialog = false
            )
        }
    }

    fun startLocationSharing() {
        _uiState.update { it.copy(isSharingActive = true) }
    }

    fun stopLocationSharing() {
        _uiState.update { it.copy(isSharingActive = false) }
    }

    fun showFeatureNotice(title: String, message: String) {
        _uiState.update {
            it.copy(
                showFeatureNoticeDialog = true,
                featureNoticeTitle = title,
                featureNoticeMessage = message
            )
        }
    }

    fun dismissFeatureNotice() {
        _uiState.update {
            it.copy(
                showFeatureNoticeDialog = false,
                featureNoticeTitle = "",
                featureNoticeMessage = ""
            )
        }
    }

    fun zoomInMap() {
        _uiState.update { it.copy(mapZoomLevel = (it.mapZoomLevel + 0.25f).coerceAtMost(3.0f)) }
    }

    fun zoomOutMap() {
        _uiState.update { it.copy(mapZoomLevel = (it.mapZoomLevel - 0.25f).coerceAtLeast(0.5f)) }
    }

    fun setMapLayer(layer: String) {
        _uiState.update { it.copy(selectedMapLayer = layer) }
    }
}
