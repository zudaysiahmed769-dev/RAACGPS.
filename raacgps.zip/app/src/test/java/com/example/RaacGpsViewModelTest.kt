package com.example

import com.example.model.NavigationTab
import com.example.viewmodel.RaacGpsViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class RaacGpsViewModelTest {

    private lateinit var viewModel: RaacGpsViewModel

    @Before
    fun setup() {
        viewModel = RaacGpsViewModel()
    }

    @Test
    fun defaultState_isGurigaTab() {
        val state = viewModel.uiState.value
        assertEquals(NavigationTab.GURIGA, state.currentTab)
        assertFalse(state.isSharingActive)
        assertFalse(state.isPermissionGranted)
    }

    @Test
    fun selectTab_updatesCurrentTab() {
        viewModel.selectTab(NavigationTab.KHARIIDADDA)
        assertEquals(NavigationTab.KHARIIDADDA, viewModel.uiState.value.currentTab)

        viewModel.selectTab(NavigationTab.QOYSKA)
        assertEquals(NavigationTab.QOYSKA, viewModel.uiState.value.currentTab)

        viewModel.selectTab(NavigationTab.DEJINTA)
        assertEquals(NavigationTab.DEJINTA, viewModel.uiState.value.currentTab)
    }

    @Test
    fun onMyLocationClicked_whenPermissionNotGranted_showsExplanationDialog() {
        assertFalse(viewModel.uiState.value.isPermissionGranted)
        viewModel.onMyLocationClicked()
        assertTrue(viewModel.uiState.value.showPermissionExplanationDialog)
    }

    @Test
    fun permissionResult_updatesState() {
        viewModel.onPermissionResult(true)
        assertTrue(viewModel.uiState.value.isPermissionGranted)
        assertFalse(viewModel.uiState.value.isPermissionDenied)
        assertFalse(viewModel.uiState.value.showPermissionExplanationDialog)
    }

    @Test
    fun locationSharing_startAndStop() {
        viewModel.startLocationSharing()
        assertTrue(viewModel.uiState.value.isSharingActive)

        viewModel.stopLocationSharing()
        assertFalse(viewModel.uiState.value.isSharingActive)
    }
}
